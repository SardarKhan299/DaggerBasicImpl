package com.example.basicdaggerimpl.di

import android.app.Application
import dagger.Module
import dagger.Provides

// Dependencies that are not related to Activities. (retrofit Instance , glide instance etc)
@Module
class AppModule {
    @Module
    companion object {
        @JvmStatic @Provides
        fun getString() = "this is a test string"

        @JvmStatic @Provides
        fun getApp(app:Application):Boolean{
           return app == null
        }

    }
}